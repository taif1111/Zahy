-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 30, 2023 at 01:19 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `zahy`
--

-- --------------------------------------------------------

--
-- Table structure for table `person`
--

CREATE TABLE `person` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `type` varchar(20) NOT NULL DEFAULT 'user'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `person`
--

INSERT INTO `person` (`id`, `name`, `email`, `password`, `mobile`, `type`) VALUES
(1, 'admin', 'admin@admin.com', 'admin', '0551234567', 'admin'),
(10, 'asma', 'asma@gmail.com', 'ASMA', '0598371932', 'user'),
(3, 'user', 'user@user.com', 'user', '0578934222', 'user'),
(6, 'طيف عبد العزيز', 'taif8920@gmail.com', 'taif', '0502589719', 'user'),
(7, 'بلدية المصيف', 'municipalM@municipal.com', 'municipalM', '0502589718', 'municipal'),
(8, 'بلدية الاحياء الجنوبية', 'municipalG@municipal.com', 'municipalG', '0502589715', 'municipal'),
(9, 'بلدية الحمراء', 'municipalR@municipal.com', 'municipalR', '0502589713', 'municipal'),
(11, 'ياسمين', 'Ysman@gmail.com', 'Ysman', '0584928762', 'user'),
(12, 'مسك', 'Mask@gmail.com', 'Mask', '0583987213', 'user');

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE `report` (
  `id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `details` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `lon` double NOT NULL,
  `lat` double NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'قيد التنفيذ',
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` int(11) NOT NULL,
  `municipal_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `report`
--

INSERT INTO `report` (`id`, `title`, `details`, `img`, `lon`, `lat`, `status`, `created`, `user_id`, `municipal_id`) VALUES
(7, 'اثاث حدائق عامة', 'اثاث حديقة حي الحمراء تالفة ', 'Chanticleer Part 2_ Garden Seating.jpeg', 36.512615993412346, 28.38399405024791, 'قيد التنفيذ', '2023-07-29 00:25:33', 12, 9),
(3, 'سيارات قديمة', 'سيارات قديمة تشوة منظر الحي', 'WhatsApp Image 2023-07-12 at 6.05.14 PM.jpeg', 36.4795404, 28.3961956, 'تم التأكيد', '2023-07-28 22:11:04', 6, 7),
(4, 'انارة لا تعمل', 'انارة لا تعمل', 'WhatsApp Image 2023-07-12 at 6.05.29 PM (1).jpeg', 36.51950316645921, 28.408819043059673, 'قيد التنفيذ', '2023-07-28 22:11:55', 6, 8),
(5, 'حفر ', 'حقر ', 'The working mans digging.jpeg', 36.52739958979905, 28.377891959135496, 'قيد التنفيذ', '2023-07-28 23:59:43', 6, 9),
(6, 'اصلاح رصيف', 'رصيف شارع مدمر', '5567db27-39be-42ef-b5a4-ed0d4a75503f.jpeg', 36.54971556880296, 28.41292586694702, 'تم التأكيد', '2023-07-29 00:00:50', 6, 7),
(8, 'المباني', 'الكتابة المشوهة للجدران والدهان', 'images.jpeg', 36.53323607661546, 28.41238232719103, 'قيد التنفيذ', '2023-07-29 00:28:21', 12, 8),
(9, 'الطرق والشوارع', 'حفر الشوارع', '20190525150348477.jpg', 36.529116203568584, 28.44444647828997, 'تم التأكيد', '2023-07-29 00:29:26', 12, 7),
(10, 'البناء تحت الانشاء', 'تسوير المباني تحت الانشاء', '1086200.jpg', 36.51126342036546, 28.368648324070037, 'قيد التنفيذ', '2023-07-29 00:30:52', 12, 9);

-- --------------------------------------------------------

--
-- Table structure for table `request`
--

CREATE TABLE `request` (
  `id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `lon` double NOT NULL,
  `lat` double NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'قيد التنفيذ',
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` int(11) NOT NULL,
  `municipal_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `request`
--

INSERT INTO `request` (`id`, `title`, `date`, `time`, `lon`, `lat`, `status`, `created`, `user_id`, `municipal_id`) VALUES
(3, 'طلب', '2023-07-29', '14:40:00', 36.522799066992185, 28.418723466894054, 'تم القبول', '2023-07-28 15:41:12', 3, 7),
(4, 'اثاث قديم', '2023-08-02', '08:01:00', 36.48723082759202, 28.422527965682534, 'قيد التنفيذ', '2023-07-29 00:01:32', 6, 8),
(5, 'بقايات طعم للمطعم', '2023-08-03', '00:04:00', 36.531862785599834, 28.366533655408986, 'قيد التنفيذ', '2023-07-29 00:05:09', 6, 8),
(6, 'ملابس ', '2023-08-05', '06:05:00', 36.56688170649827, 28.391302857753484, 'قيد التنفيذ', '2023-07-29 00:05:51', 6, 9),
(7, 'اجهزة الكترونية', '2023-08-03', '06:31:00', 36.529116203568584, 28.445231355248147, 'قيد التنفيذ', '2023-07-29 00:32:00', 12, 7);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `person`
--
ALTER TABLE `person`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `report`
--
ALTER TABLE `report`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `request`
--
ALTER TABLE `request`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `person`
--
ALTER TABLE `person`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `report`
--
ALTER TABLE `report`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `request`
--
ALTER TABLE `request`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
