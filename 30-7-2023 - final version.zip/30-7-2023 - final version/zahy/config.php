<?php
// connect to the server
$con = mysqli_connect ( "localhost", "root", "", "zahy" ) or die ( "Sorry can't connect to the server" );

// select the database
// mysql_select_db ( "zahy" ) or die ( "Sorry can't find this database" );

// satart the session var
session_start ();
ob_start ();

// to remove all notice messages
error_reporting ( E_ALL & ~E_NOTICE );

// for arabic 
mysqli_query ($con, "SET NAMES utf8");
?>