﻿<style>
#map {
	height: 100%;
	width: 100%;
}
</style>

<center>
	<div id="map"></div>
</center>

<script>
	function initMap() {
		var latlng = {lat: <?php echo $_GET['lat'];?>, lng: <?php echo $_GET['lon'];?>};
		var map = new google.maps.Map(document.getElementById('map'), {
			zoom: 12,
			center: latlng
		});
		var marker = new google.maps.Marker({
			position: latlng,
			title: "احداثيات الموقع",
			map: map
		});
	}
</script>

<script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBBfZ0v13H4s57O6OdyYfywFm4cts0aFKU&callback=initMap"> </script>