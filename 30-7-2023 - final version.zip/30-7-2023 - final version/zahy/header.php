<?php include 'config.php'; ?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Zahy - زاهي</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/logo.png" rel="icon">
  <link href="assets/img/logo.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <style>
	th, td {
		padding: 5px;
		text-align: center;
		background-color: #fff;
	}
	
	th {
		background-color: #ccc;
	}
	
	.success {
		color: green;
	}
	
	.error {
		color: red;
	}
  </style>
</head>

<body dir="rtl">

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top d-flex align-items-center">
    <div class="container d-flex align-items-center justify-content-between">

      <div class="logo">
        <!-- <h1 class="text-light"><a href="index.php"><span>Emergency cart</span></a></h1> -->
        <!-- Uncomment below if you prefer to use an image logo -->
        <a href="index.php"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>
      </div>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="index.php#hero">الرئيسية</a></li>
          <li><a class="nav-link scrollto" href="index.php#about">من نحن</a></li>
          <li><a class="nav-link scrollto" href="index.php#services">خدماتنا</a></li>
          <li><a class="nav-link scrollto" href="index.php#contact">تواصل معنا</a></li>
		  
          <?php if ($_SESSION ['user_type'] != "") { ?>
			  <li class="dropdown"><a href="#"><span>القائمة</span> <i class="bi bi-chevron-down"></i></a>
				<ul>
					<?php
					// show users menu
					if ($_SESSION ['user_type'] == "admin") {
						echo "<li><a href='admin_show_users.php'>المستخدمين</a></li>";
						echo "<li><a href='admin_show_municipals.php'>البلديات</a></li>";
						echo "<li><a href='admin_show_reports.php'>البلاغات</a></li>";
						echo "<li><a href='admin_show_requests.php'>الطلبات</a></li>";
						echo "<li><a href='admin_profile.php'>الملف الشخصي</a></li>";
						echo "<li><a href='logout.php'>تسجيل خروج</a></li>";
					} else if ($_SESSION ['user_type'] == "user") {
						echo "<li><a href='user_send_report.php'>ارسال بلاغ</a></li>";
						echo "<li><a href='user_show_reports.php'>عرض البلاغات</a></li>";
						echo "<li><a href='user_send_request.php'>ارسال طلب</a></li>";
						echo "<li><a href='user_show_requests.php'>عرض الطلبات</a></li>";
						echo "<li><a href='user_profile.php'>الملف الشخصي</a></li>";
						echo "<li><a href='logout.php'>تسجيل خروج</a></li>";
					} else if ($_SESSION ['user_type'] == "municipal") {
						echo "<li><a href='municipal_show_reports.php'>عرض البلاغات</a></li>";
						echo "<li><a href='municipal_show_requests.php'>عرض الطلبات</a></li>";
						echo "<li><a href='municipal_profile.php'>الملف الشخصي</a></li>";
						echo "<li><a href='logout.php'>تسجيل خروج</a></li>";
					}
					?>
				</ul>
			  </li>
		  <?php } else { ?>
				<li><a href='user_register.php'>تسجيل جديد</a></li>
				<li><a href='login.php'>تسجيل دخول</a></li>
				<li><a href='user_forget_password.php'>استعادة كلمة المرور</a></li>
		  <?php } ?>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <main id="main">

    <!-- ======= Breadcrumbs Section ======= -->
    <section class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2><?php echo $page_title; ?></h2>
        </div>

      </div>
    </section><!-- End Breadcrumbs Section -->

    <section class="contact" id="contact">
      <div class="container">