<?php include 'config.php'; ?>

<?php
$page_class = "contact";
$page_title = "اضافة بلدية";
?>

<?php
if ($_SESSION ['user_type'] != "admin") {
	header ( "Location: index.php" );
	die ();
}
?>

<?php include 'header.php'; ?>

<?php
if (isset ( $_POST ['name'] )) {
	// person vars
	$name = $_POST ['name'];
	$email = $_POST ['email'];
	$password = $_POST ['password'];
	$mobile = $_POST ['mobile'];
	
	// query to check if the person has registerd before or not
	$personname_query = mysqli_query ($con, "SELECT * FROM person WHERE email = '$email' OR mobile = '$mobile'" ) or die ( 'error ' . mysqli_error ($con) );
	
	if (mysqli_num_rows ( $personname_query ) != 0) {
		echo "<div class='alert alert-danger'>
					<span><h4> الايميل او الجوال تم تسجيله من قبل</h4></span>
			  </div>";
	} else {
		// insert query for person
		$query = "INSERT INTO person 
		(name, password, email, mobile, type)
		VALUES
		('$name', '$password', '$email', '$mobile', 'municipal')";
		
		//echo $query;
		
		$person_result = mysqli_query ($con, $query ) or die ( "Can't add this person" . mysqli_error ($con) );
		
		// if there is affected rows in the database;
		if (mysqli_affected_rows ($con) == 1) {
			echo "<h3 class='success'>تمت العملية بنجاح</h3>";
		} else {
			echo "<h3 class='error'>حدث خطأ أثناء تنفيذ العملية</h3>";
		}
		
		// redirect to the home page
		header ( "REFRESH:3; url=admin_show_municipals.php" );
	}
} else { ?>
	<div class="center col-lg-12 mt-5 mt-lg-0 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="200">
		<form method="post" role="form" class="php-email-form">
		  <div class="form-group mt-3">
			<label for="name">الاسم</label>
			<input type="text" class="form-control" name="name" id="name" required />
		  </div>
		  <div class="form-group mt-3">
			<label for="email">الايميل</label>
			<input type="email" class="form-control" name="email" id="email" required />
		  </div>
		  <div class="form-group mt-3">
			<label for="password">كلمة المرور</label>
			<input type="password" class="form-control" name="password" id="password" required />
		  </div>
		  <div class="form-group mt-3">
			<label for="mobile">الجوال</label>
			<input type="text" class="form-control" name="mobile" id="mobile" pattern="05[0-9]{8}" required />
		  </div>
		  <div class="text-center"><button type="submit">اضافة</button></div>
		</form>
	</div>
<?php } ?>

<?php include 'footer.php'; ?>