<?php $page_title = "جميع الطلبات";?>

<?php include 'header.php';?>

<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "admin") {
	header ( "Location: index.php" );
}
?>

<table align="center" width="100%">
	<tr>
		<th>العنوان</th>
		<th>البلدية</th>
		<th>تاريخ ووقت وصول البلدية</th>
		<th>الحالة</th>
		<th>تاريخ الارسال</th>
		<th>الموقع</th>
		<th>#</th>
	</tr>
<?php
$requests = mysqli_query ( $con, "select request.*, person.name AS municipal_name FROM request LEFT JOIN person ON request.municipal_id = person.id" );

while ( $request = mysqli_fetch_array ( $requests ) ) {
	?>
	<tr>
		<td> <?php echo $request['title'];?> </td>
		<td> <?php echo $request['municipal_name'];?> </td>
		<td> <?php echo $request['date'] . " " . $request['time'];?> </td>
		<td> <?php echo $request['status'];?> </td>
		<td> <?php echo $request['created'];?> </td>
		<td><a target="_blank" href="show_location.php?lon=<?php echo $request['lon']?>&lat=<?php echo $request['lat'];?>">Open</a></td>
		<td>
			<a href="admin_delete_request.php?id=<?php echo $request['id'];?>">حذف</a>
		</td>
	</tr>
<?php } ?>
</table>

<?php include 'footer.php'; ?>