<?php include 'config.php'; ?>

<?php
$page_class = "contact";
$page_title = "تعديل الملف الشخصي";
?>

<?php
if ($_SESSION ['user_type'] != "municipal") {
	header ( "Location: index.php" );
	die ();
}
?>

<?php include 'header.php'; ?>

<?php
if (isset ( $_POST ['name'] )) {
	$name = $_POST ['name'];
	$email = $_POST ['email'];
	$password = $_POST ['password'];
	$mobile = $_POST ['mobile'];
	
	$query = "UPDATE person SET name = '$name', email = '$email', password = '$password', mobile = '$mobile' WHERE id = '$_SESSION[user_id]'";
	$result = mysqli_query ($con, $query ) or die ( "Error add " . mysqli_error ($con) );
	
	if (mysqli_affected_rows ($con) == 1) {
		echo "<h3 class='success'>تمت العملية بنجاح</h3>";
	} else {
		echo "<h3 class='error'>حدث خطأ أثناء تنفيذ العملية</h3>";
	}
	
	header ( "REFRESH:3; url=municipal_profile.php" );
} else { ?>

<?php 
$municipal_query = mysqli_query ($con,"SELECT * FROM person WHERE id = '$_SESSION[user_id]'");
$municipal_row = mysqli_fetch_array ($municipal_query); 
?>

<div class="center col-lg-12 mt-5 mt-lg-0 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="200">
	<form method="post" role="form" class="php-email-form">
	  <div class="form-group mt-3">
		<label for="name">الاسم</label>
		<input type="text" class="form-control" name="name" id="name" value="<?php echo $municipal_row ['name'];?>" required />
	  </div>
	  <div class="form-group mt-3">
		<label for="email">الايميل</label>
		<input type="email" class="form-control" name="email" id="email" value="<?php echo $municipal_row ['email'];?>" required />
	  </div>
	  <div class="form-group mt-3">
		<label for="password">كلمة المرور</label>
		<input type="password" class="form-control" name="password" id="password" value="<?php echo $municipal_row ['password'];?>" required />
	  </div>
	  <div class="form-group mt-3">
		<label for="mobile">الجوال</label>
		<input type="text" class="form-control" name="mobile" id="mobile" value="<?php echo $municipal_row ['mobile'];?>" pattern="05[0-9]{8}" required />
	  </div>
	  
	  <div class="text-center"><button type="submit">تعديل</button></div>
	</form>
  </div>
<?php } ?>

<?php include 'footer.php'; ?>