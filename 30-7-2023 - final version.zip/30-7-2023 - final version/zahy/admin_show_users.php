<?php include 'config.php'; ?>

<?php
$page_class = "contact";
$page_title = "جميع المستخدمين في النظام";
?>

<?php
if ($_SESSION ['user_type'] != "admin") {
	header ( "Location: index.php" );
	die ();
}
?>

<?php include 'header.php'; ?>

<?php
// get user details
$user = mysqli_query ($con, "SELECT * FROM person WHERE type = 'user'" );
?>

<table class="table-bordered" width="100%">
	<tr>
		<th>الاسم</th>
		<th>الايميل</th>
		<th>الجوال</th>
		<th>#</th>
	</tr>

<?php while ($user_row = mysqli_fetch_array ( $user )) {?>
	<tr>
		<td><?php echo $user_row['name'];?></td>
		<td><?php echo $user_row['email'];?></td>
		<td><?php echo $user_row['mobile'];?></td>
		<td>
			<a href="admin_delete_user.php?id=<?php echo $user_row['id'];?>">حذف</a>
		</td>
	</tr>
<?php }?>

</table>

<?php require 'footer.php'; ?>