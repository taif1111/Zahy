<?php $page_title = "ارسال بلاغ عن مخالفة جديد";?>

<?php include 'header.php';?>


<style>
#map {
	height: 400px;
	width: 100%;
}
</style>

<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "user") {
	header ( "Location: index.php" );
}

if (isset ( $_POST ['btn-submit'] )) {
	// report vars
	$title = $_POST ['title'];
	$details = $_POST ['details'];
	$lon = $_POST ['lon'];
	$lat = $_POST ['lat'];
	$municipal_id = $_POST ['municipal_id'];
	$user_id = $_SESSION ['user_id'];
	$img = $_FILES ["img"] ["name"];
	
	// script for upload file
	// check for img type ( gif, jpg, jpeg, png )
	// and size less than 1 mb
	if ((($_FILES ["img"] ["type"] == "image/gif") || ($_FILES ["img"] ["type"] == "image/jpeg") || ($_FILES ["img"] ["type"] == "image/jpg") || ($_FILES ["img"] ["type"] == "image/png")) && ($_FILES ["img"] ["size"] < 1000000)) {
		// save the file in the img folder
		move_uploaded_file ( $_FILES ["img"] ["tmp_name"], "assets/img/reports/" . $_FILES ["img"] ["name"] );
		
		if (mysqli_query ( $con, "INSERT INTO report (title, details, img, lon, lat, user_id, municipal_id) VALUES ('$title', '$details', '$img', '$lon', '$lat', '$user_id', '$municipal_id')" )) {
			echo "<script>alert('تم ارسال البلاغ بنجاح');</script>";
		} else {
			echo "<script>alert('حدث خطأ أثناء ارسال البلاغ');</script>";
		}
	} else {
		echo "<script>alert('خطأ في رفع الصورة ... حاول ( jpg, png, gif ) ومساحة اقل من 1 ميجا');</script>";
	}
}
?>

<?php
// get municipal details
$municipals = mysqli_query ($con, "SELECT * FROM person WHERE type = 'municipal'" );
?>

<div class="contact" data-aos="fade-up" id="contact">
	<div class="row justify-content-center" data-aos="fade-up" data-aos-delay="200">
		<div class="col-xl-9 col-lg-12 mt-4">
			<form method="post" role="form" class="php-email-form" enctype="multipart/form-data">
				<div class="form-group mt-3">
					العنوان
					<input type="text" name="title" class="form-control" placeholder="العنوان" required />
				</div>
				<div class="form-group mt-3">
					التفاصيل
					<textarea name="details" class="form-control" placeholder="التفاصيل" required></textarea>
				</div>
				<div class="form-group mt-3">
					الصورة
					<input type="file" name="img" class="form-control" required accept="image/*" />
				</div>
				<div class="form-group mt-3">
					الموقع
					<div id="map" align="center"></div>
				</div>
				<div class="form-group mt-3">
					البلدية
					<select name="municipal_id" class="form-control">
						<?php while ($municipal_row = mysqli_fetch_array ( $municipals )) { ?>
							<option value="<?php echo $municipal_row['id'];?>"><?php echo $municipal_row['name'];?></option>
						<?php } ?>
					</select>
				</div>
				
				<input type="hidden" name="lat" id="lat" value="28.3961956" />
				<input type="hidden" name="lon" id="lon" value="36.4795404" />
				
				<div class="text-center">
					<button type="submit" name="btn-submit">ارسال البلاغ</button>
				</div>
			</form>
		</div>
	</div>
</div>

<script type="text/javascript">
	var map;
	var markers = [];
	
	function initMap() {
		var latitude = 28.3961956; // YOUR LATITUDE VALUE
		var longitude = 36.4795404; // YOUR LONGITUDE VALUE
		
		var myLatLng = {lat: latitude, lng: longitude};
		
		map = new google.maps.Map(document.getElementById('map'), {
		  center: myLatLng,
		  zoom: 12,
		  disableDoubleClickZoom: true, // disable map zoom on double click
		});
				
		var marker = new google.maps.Marker({
		  position: myLatLng,
		  map: map,
		  name: "موقع البلاغ"
		});

		// add the marker to the markers array
		markers.push(marker);
		
		// Create new marker on double click event on the map
		google.maps.event.addListener(map,'dblclick',function(event) {
//                 alert (event.latLng.lat()+', '+());
			// store the lon and lat 
			document.getElementById("lat").value = event.latLng.lat(); 
			document.getElementById("lon").value = event.latLng.lng(); 
			
//                 marker.setMap(null);
			
			removeMarkers();		// remove all the markers
			
			var marker = new google.maps.Marker({
			  position: event.latLng, 
			  map: map, 
			  name: "موقع البلاغ"
			});

			// add the marker to the markers array
			markers.push(marker);
		});
	}
	
	function removeMarkers() {
		for (var i = 0; i < markers.length; i++) {
			markers[i].setMap(null);
		}
	}
</script>

<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBBfZ0v13H4s57O6OdyYfywFm4cts0aFKU&callback=initMap" async defer></script>

<?php include 'footer.php'; ?>