<?php $page_title = "الطلبات الخاصة بك";?>

<?php include 'header.php';?>

<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "municipal") {
	header ( "Location: index.php" );
}
?>

<table align="center" width="100%">
	<tr>
		<th>العنوان</th>
		<th>المستخدم</th>
		<th>تاريخ ووقت وصول البلدية</th>
		<th>الحالة</th>
		<th>تاريخ الارسال</th>
		<th>الموقع</th>
		<th>#</th>
	</tr>
<?php
$requests = mysqli_query ( $con, "select request.*, person.name AS user_name FROM request LEFT JOIN person ON request.user_id = person.id WHERE request.municipal_id = '$_SESSION[user_id]' AND request.status = 'قيد التنفيذ'" );

while ( $request = mysqli_fetch_array ( $requests ) ) {
	?>
	<tr>
		<td> <?php echo $request['title'];?> </td>
		<td> <?php echo $request['user_name'];?> </td>
		<td> <?php echo $request['date'] . " " . $request['time'];?> </td>
		<td> <?php echo $request['status'];?> </td>
		<td> <?php echo $request['created'];?> </td>
		<td><a target="_blank" href="show_location.php?lon=<?php echo $request['lon']?>&lat=<?php echo $request['lat'];?>">فتح</a></td>
		<td><a href="municipal_change_request.php?id=<?php echo $request['id'];?>">تغيير الحالة</a></td>
	</tr>
<?php } ?>
</table>

<?php include 'footer.php'; ?>