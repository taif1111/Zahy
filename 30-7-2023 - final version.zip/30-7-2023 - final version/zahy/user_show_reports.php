<?php $page_title = "البلاغات الخاصة بك";?>

<?php include 'header.php';?>

<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "user") {
	header ( "Location: index.php" );
}
?>

<table align="center" width="100%">
	<tr>
		<th></th>
		<th>العنوان</th>
		<th>التفاصيل</th>
		<th>البلدية</th>
		<th>الحالة</th>
		<th>تاريخ الارسال</th>
		<th>الموقع</th>
	</tr>
<?php
$reports = mysqli_query ( $con, "select report.*, person.name AS municipal_name FROM report LEFT JOIN person ON report.municipal_id = person.id WHERE report.user_id = '$_SESSION[user_id]'" );

while ( $report = mysqli_fetch_array ( $reports ) ) {
	?>
	<tr>
		<td> <img src="assets/img/reports/<?php echo $report['img'];?>" width="100" height="100" /> </td>
		<td> <?php echo $report['title'];?> </td>
		<td> <?php echo $report['details'];?> </td>
		<td> <?php echo $report['municipal_name'];?> </td>
		<td> <?php echo $report['status'];?> </td>
		<td> <?php echo $report['created'];?> </td>
		<td><a target="_blank" href="show_location.php?lon=<?php echo $report['lon']?>&lat=<?php echo $report['lat'];?>">فتح</a></td>
	</tr>
<?php } ?>
</table>

<?php include 'footer.php'; ?>