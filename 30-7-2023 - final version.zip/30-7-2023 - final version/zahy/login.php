<?php include 'config.php'; ?>

<?php
$page_class = "contact";
$page_title = "تسجيل الدخول";
?>

<?php
if ($_SESSION ['user_type'] != "") {
	header ( "Location: index.php" );
	die ();
}
?>

<?php include 'header.php'; ?>

<?php
if (isset ( $_POST ['email'] ) && isset ( $_POST ['password'] )) {
	$email = $_POST ['email'];
	$password = $_POST ['password'];
	
	$query = "SELECT * FROM person WHERE email = '$email' AND password = '$password'";
	
	$user_result = mysqli_query ($con, $query ) or die ( "cant get email and password from the user" . mysqli_error ($con) );
	$user_row = mysqli_fetch_array ( $user_result );
	
	// if we find the email
	if (mysqli_num_rows ( $user_result ) == 1) {
		// set the session var for the user
		$_SESSION ['user'] = $user_row ['email'];
		$_SESSION ['user_id'] = $user_row ['id'];
		$_SESSION ['user_type'] = $user_row ['type'];
		
		// show successful mesg to the user
		echo "<h3 class='success'>تم تسجيل الدخول بنجاح</h3>";
		
		// redirect to the home page
		echo '<meta http-equiv="refresh" content="3; url=index.php" />';
	} else {
		// show error message to the user
		echo "<script>alert('خطأ في الايميل او كلمة المرور');</script>";
		echo '<meta http-equiv="refresh" content="0; url=index.php" />';
	}
} else { ?>
	<div class="center col-lg-12 mt-5 mt-lg-0 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="200">
		<form method="post" role="form" class="php-email-form">              
		  <div class="form-group mt-3">
			<label for="name">الايميل</label>
			<input type="email" class="form-control" name="email" id="email" required />
		  </div>
		  <div class="form-group mt-3">
			<label for="name">كلمة المرور</label>
			<input type="password" class="form-control" name="password" id="password" required />
		  </div>
		  <div class="text-center"><button type="submit">دخول</button></div>
		</form>
	</div>
<?php } ?>

<?php include 'footer.php'; ?>