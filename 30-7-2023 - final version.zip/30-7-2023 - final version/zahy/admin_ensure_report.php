<?php include 'config.php'; ?>

<?php
$page_class = "contact";
$page_title = "تأكيد بلاغ عن مخالفة";
?>

<?php
if ($_SESSION ['user_type'] != "admin") {
	header ( "Location: index.php" );
	die ();
}
?>

<?php include 'header.php'; ?>

<?php
// ensure the report
mysqli_query ($con, "UPDATE report SET status = 'تم التأكيد' WHERE id = $_GET[id]" ) or die ( 'error ' . mysqli_error ($con) );

// if there is affected rows in the database;
if (mysqli_affected_rows ($con) == 1) {
	echo "<h3 class='success'>تمت العملية بنجاح</h3>";
} else {
	echo "<h3 class='error'>حدث خطأ أثناء تنفيذ العملية</h3>";
}
	
header ( "REFRESH:3; url=admin_show_reports.php" );

?>

<?php include 'footer.php';?>