<?php include 'config.php'; ?>

<?php
$page_class = "contact";
$page_title = "حذف بلدية";
?>

<?php
if ($_SESSION ['user_type'] != "admin") {
	header ( "Location: index.php" );
	die ();
}
?>

<?php include 'header.php'; ?>

<?php
// delete the person
mysqli_query ($con, "DELETE FROM person WHERE id = $_GET[id]" ) or die ( 'error ' . mysqli_error ($con) );

// if there is affected rows in the database;
if (mysqli_affected_rows ($con) == 1) {
	echo "<h3 class='success'>تمت العملية بنجاح</h3>";
} else {
	echo "<h3 class='error'>حدث خطأ أثناء تنفيذ العملية</h3>";
}
	
header ( "REFRESH:3; url=admin_show_municipals.php" );

?>

<?php include 'footer.php';?>