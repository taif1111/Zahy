<?php include 'config.php'; ?>

<?php
$page_class = "contact";
$page_title = "بيانات البلديات في النظام";
?>

<?php
if ($_SESSION ['user_type'] != "admin") {
	header ( "Location: index.php" );
	die ();
}
?>

<?php include 'header.php'; ?>

<?php
// get municipal details
$municipal = mysqli_query ($con, "SELECT * FROM person WHERE type = 'municipal'" );
?>

<table class="table-bordered" width="100%">
	<tr>
		<th>الاسم</th>
		<th>الايميل</th>
		<th>الجوال</th>
		<th>#</th>
	</tr>

<?php while ($municipal_row = mysqli_fetch_array ( $municipal )) { ?>
	<tr>
		<td><?php echo $municipal_row['name'];?></td>
		<td><?php echo $municipal_row['email'];?></td>
		<td><?php echo $municipal_row['mobile'];?></td>
		<td>
			<a href="admin_edit_municipal.php?id=<?php echo $municipal_row['id'];?>">تعديل</a> | 
			<a href="admin_delete_municipal.php?id=<?php echo $user_row['id'];?>">حذف</a>
		</td>
	</tr>
<?php } ?>
	<tr>
		<td colspan="4" align="center">
			<a href="admin_add_municipal.php">اضافة</a>
		</td>
	</tr>
</table>

<?php require 'footer.php'; ?>