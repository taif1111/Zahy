<?php $page_title = "البلاغات الخاصة بك";?>

<?php include 'header.php';?>

<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "municipal") {
	header ( "Location: index.php" );
}
?>

<table align="center" width="100%">
	<tr>
		<th></th>
		<th>العنوان</th>
		<th>التفاصيل</th>
		<th>المستخدم</th>
		<th>الحالة</th>
		<th>تاريخ الارسال</th>
		<th>الموقع</th>
		<th>#</th>
	</tr>
<?php
$reports = mysqli_query ( $con, "select report.*, person.name AS user_name FROM report LEFT JOIN person ON report.user_id = person.id WHERE report.municipal_id = '$_SESSION[user_id]' AND report.status = 'تم التأكيد'" );

while ( $report = mysqli_fetch_array ( $reports ) ) {
	?>
	<tr>
		<td> <img src="assets/img/reports/<?php echo $report['img'];?>" width="100" height="100" /> </td>
		<td> <?php echo $report['title'];?> </td>
		<td> <?php echo $report['details'];?> </td>
		<td> <?php echo $report['user_name'];?> </td>
		<td> <?php echo $report['status'];?> </td>
		<td> <?php echo $report['created'];?> </td>
		<td><a target="_blank" href="show_location.php?lon=<?php echo $report['lon']?>&lat=<?php echo $report['lat'];?>">فتح</a></td>
		<td><a href="municipal_change_report.php?id=<?php echo $report['id'];?>">تغيير الحالة</a></td>
	</tr>
<?php } ?>
</table>

<?php include 'footer.php'; ?>