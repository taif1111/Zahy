<?php include 'config.php'; ?>

<?php
$page_class = "contact";
$page_title = "تغيير حالة طلب نقل نفايات وإعادة التدوير";
?>

<?php
if ($_SESSION ['user_type'] != "municipal") {
	header ( "Location: index.php" );
	die ();
}
?>

<?php include 'header.php'; ?>

<?php
if (isset ( $_POST ['status'] )) {
	$status = $_POST ['status'];
	$request_id = $_GET ['id'];
	
	$query = "UPDATE request SET status = '$status' WHERE id = '$_GET[id]'";
	$result = mysqli_query ($con, $query ) or die ( "Error add " . mysqli_error ($con) );
	
	if (mysqli_affected_rows ($con) == 1) {
		echo "<h3 class='success'>تمت العملية بنجاح</h3>";
	} else {
		echo "<h3 class='error'>حدث خطأ أثناء تنفيذ العملية</h3>";
	}
	
	header ( "REFRESH:3; url=municipal_show_requests.php" );
} else { ?>

<div class="center col-lg-12 mt-5 mt-lg-0 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="200">
	<form method="post" role="form" class="php-email-form">
	  <div class="form-group mt-3">
		<label for="name">الحالة</label>
		<input type="text" class="form-control" name="status" id="status" required />
	  </div>
	  
	  <div class="text-center"><button type="submit">تغيير</button></div>
	</form>
  </div>
<?php } ?>

<?php include 'footer.php'; ?>